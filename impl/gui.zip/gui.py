import sys
from Tkinter import *
from tkFileDialog import askopenfilename

def klasificiraj():
    print v.get()

def prikaziVektore():
    print "prikazi vektore"
    return

def prikaziKuteve():
    print "prikaziKuteve"
    return

def fileChooser():
    Tk().withdraw()
    filename = askopenfilename()
    v.set(filename)
    return

mGui = Tk()
mGui.geometry("700x600")
mGui.title("Raspoznavanje uzoraka")

photo = PhotoImage(file="image.gif")
label= Label(mGui, image=photo).pack(expand = True)

v = StringVar()
#label2= Label(mGui, bg = "white", textvariable=v).pack(fill = X)
entry = Entry(mGui, textvariable=v).pack( fill = X)
button0 = Button(text = "fileChooser", command = fileChooser).pack( fill = X)
button1 = Button(text = "Klasificiraj", command = klasificiraj).pack( fill = X)
button2 = Button(text = "Prikazi vektore", command = prikaziVektore).pack(fill = X)
button3 = Button(text = "Prikazi kuteve", command = prikaziKuteve).pack(fill = X)
mGui.mainloop()